num=10
if num%2==0 :
    print("짝수입니다.")
else:
    print("홀수 입니다.")
