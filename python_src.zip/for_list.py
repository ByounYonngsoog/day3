# for 문과 list 객체 연습
names=[ 'kim', 'lee', 'park', 'shin' ]
for name in names :
    print("My Last Name is " + name.title() )
print("The End...")
