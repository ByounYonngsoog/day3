# 1~1000 사이의 수 중 17의 배수 갯수와 그 합을 구하는 프로그램
count=0; total=0
 
for number in range(1, 1001):
    if number%17==0:
        count=count+1
        total+=number

print("17의 배수 갯수 : "+str(count))
print("17의 배수의 합 : "+str(total))
